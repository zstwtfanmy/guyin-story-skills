# G1 执行报告：最小候选修正与工程门

> 日期：2026-09-23。依据：`docs/作品级创作落地审计与生产化执行规格_20260923.md` §7 G1、§10、§11。
> 授权范围：用户批准执行 G1，并裁决 PATH 按"删冗余、外迁冷路径"处理、放弃"净增为零"自加约束、不删必要授权。**未授权**：G2/G3 任何生成、live 改码、部署、脚本源码修复、发布。

## 1. 做了什么

### 1.1 新候选版本（不覆盖历史）

- 复制历史候选 `framework-c1/` 为 `framework-c2/`（谱系：c1 按实际条件＝C2），全部内容修正只落 c2。
- 冷路径修正（不占预算）：
  1. `writing-craft.md`：删除"细节必须有去向、悬空细节删或兑现"的普适义务，按落地规格 C01 改为——事实/物体/动作/时间断裂必须修；蒜味、烟灰、铃声等生活细节可只贡献余味，不要求解释、反应或回收；"水烫"类先判上下文断裂再处理。§3 标明 ≤10/≥20 字数指令仅在权力博弈模式成立。§10 两处具名作品原句改为陌生化转述（原句不进生成上下文）。
  2. `character-relations.md`：感情线错位改为可选张力（同步发展合法，不制造假错位）；重要关系允许四类交叠、不强归唯一类。
  3. `exemplars/README.md`：体感粒度库"峰值必取、替代题材切片"与按需条款冲突，统一为按需翻阅、非必取。
  4. `tracking-transaction.md`：删除"不能跳级"措辞，与目标阶段产物校验统一；input 示例改为首次试写默认 `selection/publish=null`；清除伪装成用户锁的方法说明与占位禁锁；无用户指定原话时 `selection_basis=framework-default`；`effective_features` 由两条标签改为完整特征（行动面与人面并取）；补后补选定/发布的 JSON 示例，并明确 U2 必须先登记进 sources。
- 热路径修正：
  5. `guyin-write/SKILL.md`：prepared 补**阶段回看消费者**（读回看、核来源哈希与是否失效——补上"只产生不消费"的缺口）；ready 与发布段两处 preview 措辞由"纯内存/不写盘"改为"不写正式正文与追踪，首次可在 R 写机器证据"（preview 的真实行为）。同时删除三处真冗余：drafted 行重复的人面定义、与入口路由/pending 重复的"不拦写不追讨"、relationships 段重复的人面表述。
  6. `guyin-review/SKILL.md`：内置 fallback 基准中"只解释无冲突/情绪平直 ≥S2"与形式中立条款冲突，改为按具体阅读损失定级、低压形式不自动 ≥S2。
  7. `guyin-deslop/SKILL.md`："零报警=过度打磨"改为"零报警既不证明好也不证明过磨，按具体收益与损失判断"。

### 1.2 独立工程根 E

- 按 §11.3 建立 `engroot-g1/`：live `skills/`（九技能全树）＋`scripts/`＋`tests/`＋根 README，叠加 c2 三个技能目录的差异；不含参照小说、私人同题稿、未知文件与 `__pycache__`。
- E 全树 225 文件统一 LF（落地 §11.2：制品从经审核源树生成统一字节，不依赖安装者 Git 行尾转换）。
- 测试断言同步（不是删测试）：7 处原字串断言（A-2/A-4、Fw-09 C3、T02、T03、T07）改为针对正确段落与不变量；F.3.1 失败详情补全 missing/mismatched/load_failures 三类输出（修 §11.2 指出的遮蔽）；新增 §11.5 缺口复现测试 4 条。
- E 内重建**实验用** package-manifest（163 项），非发布交付。

## 2. 工程门证据（E，Node v20.17.0 / Python 3.12.0）

| 检查 | 结果 |
|---|---|
| `check-skill-contracts.js` | exit 0 |
| `check-doc-budget.js` | exit 0；17 登记项全部在限 |
| `tests/run-tests.js` | **743 pass / 0 fail / 0 skip，node exit 0** |
| `guyin-check-package.js verify --root E/skills` | exit 0；163 项，缺件 0、不符 0、加载失败 0 |

证据日志：`engroot-g1-firstround.log`（731/8）、`engroot-g1-round2.log`（740/3）、`engroot-g1-final.log`（743/0）。外层命令偶现 exit 1 系 TRAE 沙箱对 AppInstaller 日志的无关限制；node 进程自身退出码经单独核验为 0。

live 隔离：`git diff HEAD -- skills scripts tests` 为空；全部新增位于未跟踪的 `arena/`。

## 3. PATH 账（诚实口径）

| 项 | live | c1 快照 | c2（G1 后） |
|---|---:|---:|---:|
| write SKILL | 5254 | 5294 | 5298 |
| profile | 7700 | 7688 | 7688 |
| **PATH** | **12954** | 12982 | **12986（净增 32）** |

- 没有满足旧计划自加的"净增为零"；用户已明确同意不搞数字对冲。
- G1 在 write SKILL 真实删了约 45 字重复内容；新增约 49 字全部为必要授权与接口（回看消费、preview 真实语义）。review SKILL 净减 1，profile 净减 12；deslop 顶格 1540。
- 未调高任何 budget；PATH 余量 14。实际每章 token 读入量（含临时 consult、书内资料）自 G2 起逐轮登记，不用登记字符冒充。

## 4. §11.5 处置消费缺口：已复现，未修复

复现链（E 测试 G1 ①–④，夹具在系统临时目录）：
1. 书级 POV＝第三有限（POV=燕衡），草稿含配角"书办"内心直写两处 → ai-patterns 报 pov-drift（verify 级，severity 显示 advisory）。
2. 用户裁决五测试通过：`豁免台账#1` 登记，`待审台账` 行转「豁免」终态 → pending 门 exit 0，无 open blocker（合法终态成立）。
3. 同稿重跑 ai-patterns → pov-drift **原样存在**：检查器不读豁免台账。
4. 候选链汇总 → ai-patterns 状态恒为 findings、汇总非 pass → publish 的 `_verify_candidate_checks` 必拒（脚本 2584–2591）。

结论："误报→有证据获准处置→重跑→发布"的最小合法路径当前走不通；这是真实阻断缺口，不是推测。

**建议的脚本修复范围（未实施，待用户另批）**：
- `guyin-check-ai-patterns.js`：仅当存在**绑定豁免**（待审行终态＝豁免、决定依据指向豁免台账具体条目，且条目覆盖该 finding 的章号/位置/稿哈希）时，把对应 pov-drift 标记为合法已豁免态；无绑定或新稿 finding 不消除；豁免不泛化、不清空其他检查。
- `lib/guyin-candidate-context.js`：消费上述绑定/标记，使该检查状态进入合法终态、整体可 pass。
- publish 侧本就真实重跑，链路打通后无需放宽（不把 verify 全降 advisory，不引入"豁免清空新稿"）。
- 测试：G1 ③④ 两条由"缺口存在"翻转为修复后行为断言。
- 若修复中发现 Python 侧另需改动，再补差异——不预设扩大范围。

## 5. 明确没有做的事

- 没有 G2 定向研究/校准、没有 G3 生成、没有封题（G0 封题须由用户或未参加调参的独立会话在调参前完成，调参者不能自封；这是 G2/G3 的前置，不补做）。
- 没有改 live 任何文件，没有部署、没有 publish、没有 git 提交。
- 没有登记任何 Y/T-L1–L5；工程门通过不等于阅读验收，更不等于作品交付。

## 6. 下一步（待用户指令）

1. 用户决定是否先批 §11.5 脚本修复（建议在 G2 前修，否则真实写章遇 POV 阻断只能停）。
2. G0：用户/独立会话封存两题。
3. 进入 G2：研究与三类校准预算分别确认，先交一对、再定追加。

---

## 7. §11.5 修复完成记录（2026-09-24，用户当批授权）

**实际改动（4 个脚本，全部位于 framework-c2，live 未动）：**

1. `guyin-check-ai-patterns.js`：新增 `loadPovExemption`——逐项核验**豁免绑定**：待审台账行（章号＝本章、报警匹配 pov、处置类别＝verify、正文版本＝当前稿 hash12——空版本不接受、终态＝豁免、决定依据含"豁免台账#N"）＋豁免台账 #N 条目存在且位置覆盖本章。全部成立才给 pov-drift finding 挂 `resolution:exempted`＋`exemption{ledger,entry,version}`；台账读/解析异常一律不豁免（fail-closed）。主流程门只对未绑定 finding 计阻断；非 JSON 输出附"（已豁免…#N）"。
2. `lib/guyin-candidate-context.js`：汇总时消费脚本核验过的豁免标记，检查入 pass，同时在证据条目 `exemptions` 逐条登记 type/条目/稿版本（审计可查）。
3. `guyin-check-beat.js`：修复中发现的假阳性——纯文本章标题行（"第一章""第一章 守店"）此前被 meta-leak-beat 判工程词；新增标题行排除（"第一章我就…"无空格叙事句仍报）。
4. `guyin-check-authority-leak.js`：explicit 模式工序词检查做同样的标题行排除。

**验证证据：**
- 功能全量：745 项中 744 pass，唯一 1 fail 为脚本变更导致 package-manifest 过期（F.3.1）。
- 重建实验清单后 `verify` → exit 0（163 项，缺件/不符/加载失败全 0）；清单重建后的全量重跑由用户跳过，未宣称该轮结果。
- 反例测试⑤：改稿（hash 变）→ 豁免不跟随、finding 仍阻断，证明不泛化。
- 未放宽任何处置：verify 未降级，豁免绑定具体稿哈希，publish 侧仍真实重跑。

**修复中的工程取舍：**
- 台账行解析在 ai-patterns 内为约 20 行的自含小解析器（pending.js 有独立解析，跨脚本复用需重构 pending，爆炸半径更大）；语义不矛盾且更严格（稿 hash 绑定）。
- 夹具书初始化改用正式 `init` 事务而非手拼 state/views，避免派生子集不一致。

**仍待：** G0 封题（用户本人或独立会话，调参者不能自封），随后进 G2。
